	   pkill gzclient
	   echo "Killing gzclient"
           pkill gzserver
	   echo "Killing gzserver"
#           pkill rqt
#	   echo "Killing rqt"
#           sleep 1
#	   rosnode kill -a
	   pkill roslaunch
	   echo "Killing roslaunch"
           sleep 1
#	   pkill rosmaster
#	   echo "Killing rosmaster"
#           sleep 1
#           pkill roscore
#	   echo "Killing roscore"
 #          sleep 1
